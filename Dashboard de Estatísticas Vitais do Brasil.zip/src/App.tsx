
import React from 'react'

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <p>Give Lumi a thought, and watch it glow.</p>
    </div>
  )
}

export default App

