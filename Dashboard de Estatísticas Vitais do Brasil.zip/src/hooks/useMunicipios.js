
import { useState, useEffect, useCallback } from 'react'
import apiService from '../services/api'

export const useMunicipios = (estadoSelecionado) => {
  const [municipios, setMunicipios] = useState([])
  const [estatisticasMunicipios, setEstatisticasMunicipios] = useState({})
  const [loading, setLoading] = useState(false)

  const loadMunicipios = useCallback(async (estadoId) => {
    if (!estadoId) {
      setMunicipios([])
      setEstatisticasMunicipios({})
      return
    }

    try {
      setLoading(true)
      const municipiosData = await apiService.getMunicipiosByUf(estadoId)
      setMunicipios(municipiosData)

      // Carregar estatísticas para cada município
      const estatisticasPromises = municipiosData.map(async (municipio) => {
        try {
          const estatisticas = await apiService.getEstatisticasMunicipio(municipio.id)
          return { municipioId: municipio.id, estatisticas }
        } catch (error) {
          console.error(`Erro ao carregar estatísticas do município ${municipio.id}:`, error)
          return { municipioId: municipio.id, estatisticas: [] }
        }
      })

      const estatisticasResults = await Promise.all(estatisticasPromises)
      const estatisticasMap = {}
      
      estatisticasResults.forEach(({ municipioId, estatisticas }) => {
        estatisticasMap[municipioId] = estatisticas
      })

      setEstatisticasMunicipios(estatisticasMap)
    } catch (error) {
      console.error('Erro ao carregar municípios:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadMunicipios(estadoSelecionado)
  }, [estadoSelecionado, loadMunicipios])

  const getTotalByMunicipio = useCallback((municipioId, tipoRegistro, ano) => {
    const estatisticas = estatisticasMunicipios[municipioId] || []
    return apiService.calculateTotals(estatisticas, tipoRegistro, ano)
  }, [estatisticasMunicipios])

  return {
    municipios,
    estatisticasMunicipios,
    loading,
    getTotalByMunicipio
  }
}
