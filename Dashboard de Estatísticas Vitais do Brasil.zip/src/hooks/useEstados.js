
import { useState, useEffect, useCallback } from 'react'
import apiService from '../services/api'

export const useEstados = () => {
  const [estados, setEstados] = useState([])
  const [estatisticasEstados, setEstatisticasEstados] = useState({})
  const [loading, setLoading] = useState(true)

  const loadEstados = useCallback(async () => {
    try {
      setLoading(true)
      const estadosData = await apiService.getEstados()
      setEstados(estadosData)

      // Carregar estatísticas para cada estado
      const estatisticasPromises = estadosData.map(async (estado) => {
        try {
          const estatisticas = await apiService.getEstatisticasUf(estado.id)
          return { estadoId: estado.id, estatisticas }
        } catch (error) {
          console.error(`Erro ao carregar estatísticas do estado ${estado.id}:`, error)
          return { estadoId: estado.id, estatisticas: [] }
        }
      })

      const estatisticasResults = await Promise.all(estatisticasPromises)
      const estatisticasMap = {}
      
      estatisticasResults.forEach(({ estadoId, estatisticas }) => {
        estatisticasMap[estadoId] = estatisticas
      })

      setEstatisticasEstados(estatisticasMap)
    } catch (error) {
      console.error('Erro ao carregar estados:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadEstados()
  }, [loadEstados])

  const getTotalByEstado = useCallback((estadoId, tipoRegistro, ano) => {
    const estatisticas = estatisticasEstados[estadoId] || []
    return apiService.calculateTotals(estatisticas, tipoRegistro, ano)
  }, [estatisticasEstados])

  const getEstadoById = useCallback((estadoId) => {
    return estados.find(estado => estado.id === estadoId)
  }, [estados])

  return {
    estados,
    estatisticasEstados,
    loading,
    getTotalByEstado,
    getEstadoById,
    reloadEstados: loadEstados
  }
}
